Introducing Aaleyah. A magnificent curved display font. Use it to add vintage and mystique flavor to any design! It’s ready and Perfectly fit for your logo designs, headline, music projects & social media posts, event poster, brand imagery, product packaging, quotes, merchandise, etc.

Please read this before using the font.

You may use this version of 'Aaleyah' for personal use only. If you wish to use it commercially you will need to purchase a license. Click here 
https://fontbundles.net/aluyeahstudio/365549-aaleyah-and-extras

You mey like our other product
fontbundles.net/aluyeahstudio
www.creativefabrica.com/designer/aluyeah-studio/

Any Question, you can submit your question here
linggarsundoro@gmail.com
www.behance.net/aluyeahstudio

PLEASE FOLLOW & APPRECIATE OUR PROJECT, ILYSM


